# ADP-MATLAB example figures

These three figures use preserved MATLAB experiment records. No training, policy fitting or closed-loop simulation was rerun for the website revision.

Run `redraw_examples` in MATLAB from this folder to regenerate SVG, PDF, PNG and editable FIG files from `data/`.

- **Integral PI:** the original double-integrator trajectory, 401 recorded samples. Solid blue is x1; dashed teal is x2.
- **Koopman PI:** all 50 trajectories from the isolated validated normalized-pendulum run. Each curve is the recorded angle versus angular velocity under the learned policy; true-model PI is not plotted in this figure. The dot marks the equilibrium. This is the documented numerical variant of the L4DC method.
- **HJB PINN:** the trained pendulum value evaluated at the initial PDE time on a 41 × 41 common grid, final continuation stage T = 4 s, from the preserved reduced training run. The color scale reports the learned value. This is the learned neural value, not an analytic LQR value or a safety certificate.

The experiments use different mathematical problems and settings. The figures introduce the examples; they do not constitute a shared performance benchmark. Exact source paths and checksums are in `figure-data.json`.
