function redraw_examples()
%REDRAW_EXAMPLES Plot preserved experiment data for the project page.
% No fitting, training or closed-loop simulation is performed.
root=fileparts(mfilename('fullpath'));
b=readtable(fullfile(root,'data','baseline-trajectory.csv'));
k=readtable(fullfile(root,'data','koopman-trajectories.csv'));
p=readtable(fullfile(root,'data','pinn-value-grid.csv'));
assert(height(b)==401 && numel(unique(k.trajectory))==50 && height(p)==41^2);
assert(all(isfinite([b.x1;b.x2;k.x1;k.x2;p.value])));
blue=[.08 .33 .51];teal=[.18 .49 .47];gray=[.55 .60 .64];ink=[.24 .29 .32];
f=makeFigure();ax=axes(f,'Position',[.145 .21 .815 .72]);hold(ax,'on');
plot(ax,b.time,b.x1,'Color',blue,'LineWidth',2.7);
plot(ax,b.time,b.x2,'--','Color',teal,'LineWidth',2.4);
yline(ax,0,':','Color',[.7 .75 .78],'LineWidth',.6);
xlim(ax,[0 8]);ylim(ax,[-1.08 1.08]);set(ax,'XTick',[0 4 8],'YTick',[-1 0 1]);
xlabel(ax,'Time (s)');ylabel(ax,'State');
text(ax,3.05,.22,'x_1','FontSize',19,'Color',blue);
text(ax,1.2,-.61,'x_2','FontSize',19,'Color',teal);
style(ax,ink);writeFigure(f,root,'example-linear');

f=makeFigure();ax=axes(f,'Position',[.145 .21 .815 .72]);hold(ax,'on');
for j=1:50
 t=k(k.trajectory==j,:);plot(ax,t.x1,t.x2,'Color',[.46 .65 .76],'LineWidth',1.1);
end
plot(ax,0,0,'o','MarkerFaceColor',blue,'MarkerEdgeColor','white','LineWidth',1.2,'MarkerSize',7);
xline(ax,0,':','Color',[.75 .79 .82],'LineWidth',.6);yline(ax,0,':','Color',[.75 .79 .82],'LineWidth',.6);
xmax=max(abs(k.x1));ymax=max(abs(k.x2));xlim(ax,[-1 1]*1.06*xmax);ylim(ax,[-1 1]*1.06*ymax);
set(ax,'XTick',[-1 0 1],'YTick',[-1 0 1]);xlabel(ax,'Angle (rad)');ylabel(ax,'Angular velocity (rad/s)');
style(ax,ink);writeFigure(f,root,'example-koopman');

f=makeFigure();ax=axes(f,'Position',[.145 .21 .815 .72]);hold(ax,'on');
set(ax,'Position',[.145 .21 .705 .72]);
x=reshape(p.x1,41,41);y=reshape(p.x2,41,41);v=reshape(p.value,41,41);
contourf(ax,x,y,v,linspace(0,max(v,[],'all'),12),'LineStyle','none');
cmap=[linspace(.96,.09,128)',linspace(.98,.37,128)',linspace(.99,.56,128)'];colormap(ax,cmap);
contour(ax,x,y,v,[.1 .3 .6 1 1.5 2],'LineColor',[.35 .57 .70],'LineWidth',.65);
plot(ax,0,0,'o','MarkerFaceColor','white','MarkerEdgeColor',blue,'MarkerSize',5,'LineWidth',1);
xlim(ax,[-1 1]);ylim(ax,[-1 1]);set(ax,'XTick',[-1 0 1],'YTick',[-1 0 1]);
xlabel(ax,'Angle (rad)');ylabel(ax,'Angular velocity (rad/s)');
clim(ax,[0 max(v,[],'all')]);
cb=colorbar(ax,'Position',[.89 .21 .025 .72],'Ticks',[0 1 2], ...
 'FontName','Arial','FontSize',16,'Color',ink,'Box','off','TickDirection','out');
annotation(f,'textbox',[.87 .08 .07 .09],'String','V','FontName','Georgia', ...
 'FontAngle','italic','FontSize',20,'EdgeColor','none','HorizontalAlignment','center','Color',ink);
style(ax,ink);writeFigure(f,root,'example-pinn');
disp('PROJECT_EXAMPLE_FIGURES_COMPLETE');
end
function f=makeFigure()
f=figure('Visible','off','Color','white','Position',[80 80 600 390], ...
 'Renderer','painters','PaperUnits','inches','PaperPosition',[0 0 6 3.9],'PaperSize',[6 3.9]);
end
function style(ax,ink)
set(ax,'FontName','Arial','FontSize',17,'XColor',ink,'YColor',ink, ...
 'Box','off','TickDir','out','LineWidth',.65,'TickLength',[.012 .012]);
set([ax.XLabel ax.YLabel],'FontSize',17,'Color',ink);
end
function writeFigure(f,root,name)
print(f,fullfile(root,[name '.svg']),'-dsvg','-painters');
print(f,fullfile(root,[name '.png']),'-dpng','-r150');
print(f,fullfile(root,[name '.pdf']),'-dpdf','-painters');
savefig(f,fullfile(root,[name '.fig']));close(f);
end
