function redraw_hero()
%REDRAW_HERO Rebuild the project figure from the preserved baseline CSV data.
% Requires base MATLAB. No new learning or closed-loop experiment is run.
% Gray contours use the analytic CARE solution already specified by the
% baseline. The right panel normalizes incurred cost and remaining value by
% V*(x0). All arrays come from the original run or these declared transforms.
here=fileparts(mfilename('fullpath'));
c=readtable(fullfile(here,'data','baseline-convergence.csv'));
t=readtable(fullfile(here,'data','baseline-trajectory.csv'));
s=jsondecode(fileread(fullfile(here,'data','baseline-summary.json')));
P=[sqrt(3),1;1,sqrt(3)];A=[0 1;0 0];B=[0;1];
x=[t.x1,t.x2];K=[c.K1(end),c.K2(end)];
V=sum((x*P).*x,2);V0=x(1,:)*P*x(1,:)';
paid=t.integratedCost/V0;remaining=V/V0;
careResidual=norm(A'*P+P*A-P*B*B'*P+eye(2),'fro');
identityError=max(abs(paid+remaining-1));
assert(careResidual<1e-12 && all(eig(P)>0));
assert(abs(V0-s.metrics.referenceInfiniteHorizonValue)<1e-12);
assert(identityError<1e-9 && all(diff(t.integratedCost)>-1e-12));
assert(height(c)==5 && height(t)==401 && all(real(eig(A-B*K))<0));
blue=[.08 .31 .53];amber=[.65 .43 .16];ink=[.16 .18 .21];
softblue=[.89 .94 .98];softamber=[.97 .94 .88];gray=[.73 .77 .80];
f=figure('Visible','off','Color','white','Position',[30 30 1440 460], ...
    'Renderer','painters','Name','ADP-MATLAB: learning, feedback and value');

% Left: direct data with sparse ticks and an endpoint label.
a1=axes(f,'Position',[.062 .22 .215 .53]);
semilogy(a1,c.iteration,c.gainError,'-o','Color',blue,'LineWidth',2.4, ...
    'MarkerSize',6,'MarkerFaceColor','white','MarkerEdgeColor',blue);hold(a1,'on');
plot(a1,c.iteration(end),c.gainError(end),'o','MarkerSize',7,'MarkerFaceColor',blue,'MarkerEdgeColor',blue);
xlim(a1,[.8 5.25]);ylim(a1,[1e-14 1]);
set(a1,'XTick',1:5,'YTick',[1e-14 1e-7 1],'YMinorTick','off','YMinorGrid','off');
xlabel(a1,'Iteration');ylabel(a1,'Gain error');
text(a1,4.3,1.3e-13,'8.4 \times 10^{-14}','Color',blue,'FontSize',14,'HorizontalAlignment','right');

% Center: actual state trajectory over independently computed value contours.
a2=axes(f,'Position',[.335 .145 .335 .65]);hold(a2,'on');
[g1,g2]=meshgrid(linspace(-1.2,1.2,201));
value=P(1,1)*g1.^2+2*P(1,2)*g1.*g2+P(2,2)*g2.^2;
contour(a2,g1,g2,value,[.08 .3 .8 1.6 2.7],'LineColor',gray,'LineWidth',.85);
xline(a2,0,':','Color',[.83 .85 .87],'LineWidth',.7);
yline(a2,0,':','Color',[.83 .85 .87],'LineWidth',.7);
plot(a2,t.x1,t.x2,'Color',blue,'LineWidth',2.8);
plot(a2,t.x1(1),t.x2(1),'o','MarkerSize',7,'MarkerFaceColor',blue,'MarkerEdgeColor',blue);
for time=[.5 1.4]
    i=find(t.time>=time,1);j=min(i+5,height(t));
    arrowHead(a2,[t.x1(i),t.x2(i)],[t.x1(j),t.x2(j)],.06,blue);
end
plot(a2,0,0,'o','MarkerSize',6.5,'MarkerFaceColor','white','MarkerEdgeColor',ink,'LineWidth',1.6);
text(a2,1.07,-1.02,'x_0','FontSize',16,'Color',blue);
text(a2,-.12,.13,'0','FontSize',14,'Color',ink,'HorizontalAlignment','right');
xlim(a2,[-1.2 1.2]);ylim(a2,[-1.2 1.2]);axis(a2,'equal');
set(a2,'XTick',[-1 0 1],'YTick',[-1 0 1]);
xlabel(a2,'x_1');ylabel(a2,'x_2');

% Right: incurred cost + value-to-go, normalized by the initial value.
a3=axes(f,'Position',[.755 .22 .22 .53]);hold(a3,'on');
p=area(a3,t.time,[paid,remaining],'LineStyle','none');
p(1).FaceColor=softblue;p(2).FaceColor=softamber;
plot(a3,t.time,paid,'Color',blue,'LineWidth',2.4);
yline(a3,1,'--','Color',amber,'LineWidth',1.35);
xlim(a3,[0 8]);ylim(a3,[0 1.055]);set(a3,'XTick',[0 4 8],'YTick',[0 .5 1]);
xlabel(a3,'Time (s)');ylabel(a3,'Normalized value');
text(a3,5.3,.30,'cost incurred','Color',blue,'FontSize',14,'HorizontalAlignment','center');


% Shared styling: hierarchy and direct labels instead of three large grids.
set([a1 a2 a3],'FontName','Arial','FontSize',14,'Box','off','TickDir','out', ...
    'TickLength',[.016 .016],'LineWidth',.7,'XColor',[.40 .43 .46], ...
    'YColor',[.40 .43 .46],'XGrid','off','YGrid','off');
set([a1.XLabel a1.YLabel a2.XLabel a2.YLabel a3.XLabel a3.YLabel], ...
    'FontSize',15,'Color',ink);
h1=label(f,[.042 .865 .255 .07],'a   Policy learning',17,ink,'left','normal');
h2=label(f,[.342 .865 .31 .07],'b   Closed-loop trajectory',18,ink,'center','normal');
h3=label(f,[.740 .865 .255 .07],'c   Value decomposition',17,ink,'left','normal');
h4=label(f,[.790 .755 .16 .07],'remaining value',13,amber,'left','normal');
h5=annotation(f,'arrow',[.790 .773],[.764 .682],'Color',amber,'LineWidth',.8,'HeadLength',5,'HeadWidth',5);

exportgraphics(f,fullfile(here,'adp-control-hero.svg'),'ContentType','vector','BackgroundColor','white');
exportgraphics(f,fullfile(here,'adp-control-hero.pdf'),'ContentType','vector','BackgroundColor','white');
exportgraphics(f,fullfile(here,'adp-control-hero.png'),'Resolution',220,'BackgroundColor','white');
savefig(f,fullfile(here,'adp-control-hero.fig'));
exportgraphics(f,fullfile(here,'adp-control-hero-screen.png'),'Resolution',80,'BackgroundColor','white');

% A legible vertical arrangement for the same figure on a narrow screen.
f.Position=[30 30 640 1330];
a1.Position=[.20 .730 .71 .175];
a2.Position=[.17 .370 .75 .245];
a3.Position=[.20 .055 .71 .190];
h1.Position=[.085 .93 .85 .045];h2.Position=[.085 .620 .85 .045];
h3.Position=[.085 .275 .85 .045];
set([h1 h2 h3],'FontSize',23,'HorizontalAlignment','left');
h4.Position=[.35 .240 .5 .035];h4.FontSize=17;
h5.X=[.35 .27];h5.Y=[.25 .225];
set([a1 a2 a3],'FontSize',19);
set(findall(a1,'Type','text'),'FontSize',19);
set(findall(a2,'Type','text'),'FontSize',19);
set(findall(a3,'Type','text'),'FontSize',19);
exportgraphics(f,fullfile(here,'adp-control-hero-mobile.svg'),'ContentType','vector','BackgroundColor','white');
exportgraphics(f,fullfile(here,'adp-control-hero-mobile.png'),'Resolution',130,'BackgroundColor','white');
close(f);
report=struct('source','Preserved baseline CSVs; no new experiment', ...
    'referenceP',P,'referenceCAREresidual',careResidual,'valueAtInitialState',V0, ...
    'normalizedValueIdentityMaxError',identityError,'finalNormalizedIncurredCost',paid(end), ...
    'finalNormalizedRemainingValue',remaining(end),'recordedGainError',c.gainError(end), ...
    'trajectoryRows',height(t),'policyEvaluationRows',height(c), ...
    'phaseCurve','[x1(t),x2(t)] from original recorded trajectory', ...
    'contours','Analytic reference x''P*x, not a learned critic or extra rollout', ...
    'costPanel','Stacked J(0,t)/V*(x0) and x(t)''P*x(t)/V*(x0)');
fid=fopen(fullfile(here,'figure-provenance.json'),'w');fprintf(fid,'%s\n',jsonencode(report,'PrettyPrint',true));fclose(fid);
disp('ADP_HERO_RENDER_COMPLETE');
end
function h=label(f,pos,txt,fs,color,align,weight)
h=annotation(f,'textbox',pos,'String',txt,'Interpreter','tex','FontName','Arial', ...
    'FontSize',fs,'FontWeight',weight,'Color',color,'EdgeColor','none', ...
    'HorizontalAlignment',align,'VerticalAlignment','middle','Margin',0,'FitBoxToText','off');
end
function arrowHead(ax,p,q,len,color)
d=q-p;d=d/norm(d);n=[-d(2),d(1)];
pts=[q;q-len*d+.43*len*n;q-.77*len*d;q-len*d-.43*len*n];
patch(ax,pts(:,1),pts(:,2),color,'EdgeColor','none');
end
