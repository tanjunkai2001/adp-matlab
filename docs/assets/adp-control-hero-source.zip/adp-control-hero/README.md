# ADP-MATLAB project figure

This figure uses the original integral-policy-iteration example, with a double integrator, Q = I, R = 1 and x0 = [1, -1]'. No additional learning experiment or trajectory was simulated for this revision.

## Files

- `adp-control-hero.svg` and `.pdf`: vector desktop figure.
- `adp-control-hero.png`: high-resolution desktop image.
- `adp-control-hero.fig`: editable MATLAB figure. Open with `openfig`.
- `adp-control-hero-mobile.svg` and `.png`: vertical layout of the same data.
- `redraw_hero.m`: self-contained MATLAB generator; run `redraw_hero` from this directory. Rendered with MATLAB R2025b, using base MATLAB.
- `data/`: preserved CSV trajectories, policy-iteration values and the original summary.
- `figure-provenance.json`: numerical checks and declared transformations.

## Caption

**Learning, feedback and value.** Integral policy iteration on a double integrator. (a) The recorded feedback-gain error over five policy-evaluation rounds. (b) The recorded closed-loop trajectory in state space; gray contours show the analytic LQR value function. (c) Incurred cost and remaining analytic value, normalized by the initial value. The figure uses Q = I, R = 1 and x0 = [1, -1]'.

## Data and transformations

Panel (a) directly plots `iteration` and `gainError`. Panel (b) directly plots the recorded `x1` and `x2`; the arrows indicate motion along that path. Contours use the analytic CARE solution already specified in `demo_integral_pi.m`:

```matlab
P = [sqrt(3), 1; 1, sqrt(3)];
V = sum((x * P) .* x, 2);
V0 = x(1,:) * P * x(1,:)';
incurred = integratedCost / V0;
remaining = V / V0;
```

Panel (c) stacks these last two quantities. The dashed horizontal line is the normalized initial value, 1. The maximum recorded discrepancy in `incurred + remaining = 1` is 2.73e-14 or less. This identity is checked for this example. The contours are an analytic reference; they do not depict a learned critic or additional experiments.

The SVG and PDF are vector exports. The FIG retains editable labels and MATLAB graphics objects. An image-generation reference informed composition only. All quantitative curves, contours, labels and final exported assets were reconstructed in MATLAB from the data and formulas above.
